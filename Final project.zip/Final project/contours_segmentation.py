import cv2 as cv 
import numpy as np
import os

# Change path of the execution ot the path of file's directory 
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Reading camera's frames
def read_frame(capture):    
    frame_count = 0
    # Dump first 10 frames
    while(frame_count < 10):
        ret, frame = capture.read()
        frame_count += 1

    # Take a screenshot of the scene
    ret, frame = capture.read()

    return frame


def segmentation(frame):
    # blank = np.zeros(frame.shape, dtype='uint8')

    # Gray 
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    # Blur 
    #blur = cv.GaussianBlur(frame, (1,1), cv.BORDER_DEFAULT)
    # cv.imshow('Blurred image', blur)

    # Edge Cascade
    canny = cv.Canny(gray, 125, 175)
    #cv.imshow('Contours detection', canny)

    # Thresholding
    ret, thresh = cv.threshold(gray, 125, 255, cv.THRESH_BINARY)

    # Contours
    contours, hierarchies = cv.findContours(canny, cv.RETR_LIST, cv.CHAIN_APPROX_NONE) #possible to pass thresh instead of canny as first argument
    #cv.RETR_LIST returns all the contours of the image, cv.RETR_EXTERNAL returns all the external contours and cv.RETR_TREE return all the hierarchal (?) contours
    #cv.CHAIN_APPROX_NONE returns all the contours, cv.CHAIN_APPROX_SIMPLE compresses all the contours returned (ex : a line is compressed into two points)
    print(f'{len(contours)} contour(s) found !')
    cv.drawContours(frame, contours, -1, (0, 0, 255), 2) #drawing the contours found in a blank image
    cv.imshow('Contours Drawn', frame)


if __name__ == '__main__':
    # Start the video stream
    capture = cv.VideoCapture(1)

    while True:
        frame = read_frame(capture)
        segmentation(frame)

        # If "q" is pressed on the keyboard, 
        # exit this loop
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

    cv.destroyAllWindows()
    capture.release()

